Project 2

Group:
	Kyle de Bord
	Ryan Martino
	
Expected Output:
	When run, you will be promted to input two numbers, then
	prompted to select which task you would like to run.
	
	Task 1 will return number_1 * number_2, computed using
	the karatsuba method.
	
	Task 2 will return number_1 ^ number_2, computed using
	the exponentiation algorithm and karatsuba when neccesary.
	
Example:
	Number 1 = 5
	Number 2 = 10
	
	Task 1 output = 50
	Task 2 output = 9765625
	